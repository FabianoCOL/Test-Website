"use client";
import React from "react";

function MainComponent() {
  const [activeCard, setActiveCard] = useState(null);
  const [phoneNumbers, setPhoneNumbers] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [eans, setEans] = useState([]);
  const [newEan, setNewEan] = useState({
    name: "",
    ean: "",
  });
  const [newEmployee, setNewEmployee] = useState({
    name: "",
    position: "",
  });
  const [manuals, setManuals] = useState([
    {
      id: 1,
      title: "Benutzerhandbuch",
      desc: "Grundlegende Funktionen und Navigation",
    },
  ]);
  const [draggedManual, setDraggedManual] = useState(null);
  const [newNumber, setNewNumber] = useState({
    name: "",
    number: "",
    email: "",
    department: "",
    branch: "",
  });
  const cards = [
    {
      id: "contact",
      title: "Kontakte",
      icon: "fa-address-book",
      desc: "Verwalten Sie Ihre Kontakte",
    },
    {
      id: "eans",
      title: "Minus EANs",
      icon: "fa-barcode",
      desc: "Produktcodes verwalten",
    },
    {
      id: "employees",
      title: "Mitarbeiter",
      icon: "fa-users",
      desc: "Teammitglieder anzeigen und verwalten",
    },
    {
      id: "manuals",
      title: "Dokumente",
      icon: "fa-book",
      desc: "Produktdokumentation aufrufen",
    },
    {
      id: "bugs",
      title: "Trade in",
      icon: "fa-recycle",
      desc: "Geräte in Zahlung geben",
    },
    {
      id: "links",
      title: "Links",
      icon: "fa-link",
      desc: "Wichtige Links",
    },
    {
      id: "schedule",
      title: "Arbeitsplan",
      icon: "fa-calendar",
      desc: "Arbeitszeiten verwalten",
    },
  ];
  const handleAddNumber = () => {
    if (newNumber.name && newNumber.number) {
      setPhoneNumbers([...phoneNumbers, newNumber]);
      setNewNumber({ name: "", number: "" });
    }
  };
  const handleDeleteNumber = (index) => {
    const updatedNumbers = phoneNumbers.filter((_, i) => i !== index);
    setPhoneNumbers(updatedNumbers);
  };
  const handleDragStart = (manual, e) => {
    setDraggedManual(manual);
    const dragImage = document.createElement("div");
    dragImage.className =
      "bg-[#242426] p-4 rounded-lg opacity-50 pointer-events-none";
    dragImage.innerHTML = manual.title;
    document.body.appendChild(dragImage);
    e.dataTransfer.setDragImage(dragImage, 0, 0);
    setTimeout(() => document.body.removeChild(dragImage), 0);
  };
  const handleDragOver = (e) => {
    e.preventDefault();
    e.currentTarget.classList.add("bg-[#2c2c2e]");
  };
  const handleDrop = (targetManual, e) => {
    e.preventDefault();
    if (!draggedManual || draggedManual.id === targetManual.id) return;

    const updatedManuals = [...manuals];
    const draggedIndex = manuals.findIndex((m) => m.id === draggedManual.id);
    const targetIndex = manuals.findIndex((m) => m.id === targetManual.id);

    updatedManuals.splice(draggedIndex, 1);
    updatedManuals.splice(targetIndex, 0, draggedManual);

    setManuals(updatedManuals);
    setDraggedManual(null);
    e.currentTarget.classList.remove("bg-[#2c2c2e]");
  };

  useEffect(() => {
    const initializeEmployees = async () => {
      const employees = [
        { name: "Ajsela Skijil", position: "Verkauf" },
        { name: "Anis Spahic", position: "Verkauf" },
        { name: "Cedric Lustenberger", position: "Verkauf" },
        { name: "Fabian Egolf", position: "Verkauf" },
        { name: "Fabian Obertüfer", position: "Verkauf" },
        { name: "Fabiano Costa", position: "Verkauf" },
        { name: "Jan Behrens", position: "Verkauf" },
        { name: "Kavi Ramanan", position: "Verkauf" },
        { name: "Lars Arnet", position: "Verkauf" },
        { name: "Luis Büttler", position: "Verkauf" },
        { name: "Michael Wiesli", position: "Verkauf" },
        { name: "Ricardo Barrero", position: "Verkauf" },
      ];

      for (const employee of employees) {
        await fetch("/api/db/mitarbeiter-db", {
          method: "POST",
          body: JSON.stringify({
            query: "INSERT INTO `employees` (`name`, `position`) VALUES (?, ?)",
            values: [employee.name, employee.position],
          }),
        });
      }
    };

    const fetchEmployees = async () => {
      const response = await fetch("/api/db/mitarbeiter-db", {
        method: "POST",
        body: JSON.stringify({
          query: "SELECT * FROM `employees`",
        }),
      });
      const data = await response.json();
      if (!data.length) {
        await initializeEmployees();
        fetchEmployees();
      } else {
        setEmployees(data);
      }
    };
    fetchEmployees();
  }, []);

  const handleEditEmployee = async (employee) => {
    const response = await fetch("/api/db/mitarbeiter-db", {
      method: "POST",
      body: JSON.stringify({
        query:
          "UPDATE `employees` SET `name` = ?, `position` = ? WHERE `id` = ?",
        values: [employee.name, employee.position, employee.id],
      }),
    });

    if (response.ok) {
      const updatedResponse = await fetch("/api/db/mitarbeiter-db", {
        method: "POST",
        body: JSON.stringify({
          query: "SELECT * FROM `employees`",
        }),
      });
      const updatedData = await updatedResponse.json();
      setEmployees(updatedData);
    }
  };

  const handleAddEmployee = async () => {
    if (newEmployee.name && newEmployee.position) {
      const response = await fetch("/api/db/mitarbeiter-db", {
        method: "POST",
        body: JSON.stringify({
          query: "INSERT INTO `employees` (`name`, `position`) VALUES (?, ?)",
          values: [newEmployee.name, newEmployee.position],
        }),
      });

      if (response.ok) {
        const updatedResponse = await fetch("/api/db/mitarbeiter-db", {
          method: "POST",
          body: JSON.stringify({
            query: "SELECT * FROM `employees`",
          }),
        });
        const updatedData = await updatedResponse.json();
        setEmployees(updatedData);
        setNewEmployee({
          name: "",
          position: "",
        });
      }
    }
  };
  const handleDeleteEmployee = async (id) => {
    const response = await fetch("/api/db/mitarbeiter-db", {
      method: "POST",
      body: JSON.stringify({
        query: "DELETE FROM `employees` WHERE `id` = ?",
        values: [id],
      }),
    });

    if (response.ok) {
      const updatedResponse = await fetch("/api/db/mitarbeiter-db", {
        method: "POST",
        body: JSON.stringify({
          query: "SELECT * FROM `employees`",
        }),
      });
      const updatedData = await updatedResponse.json();
      setEmployees(updatedData);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-red-900 to-black text-white font-sfpro">
      <main className="pt-8 pb-16 px-4 md:px-8">
        <div className="max-w-[980px] mx-auto">
          {!activeCard ? (
            <>
              <h2 className="text-4xl md:text-5xl font-semibold text-center mb-2 md:mb-3 animate-slide-in">
                Willkommen.
              </h2>
              <p className="text-lg md:text-xl text-gray-400 text-center mb-12 md:mb-16 animate-slide-in">
                Wählen Sie aus, was Sie tun möchten.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8">
                {cards.map((card) => (
                  <button
                    key={card.id}
                    onClick={() => setActiveCard(card.id)}
                    className="group bg-[#161618] p-6 rounded-3xl text-left h-[200px] relative overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-white transform translate-x-[-100%] group-hover:translate-x-0 transition-transform duration-300"></div>
                    <div className="relative z-10">
                      <div className="bg-[#1d1d1f] group-hover:bg-white w-12 h-12 rounded-full flex items-center justify-center mb-4 transition-all duration-300">
                        <i
                          className={`fas ${card.icon} text-2xl text-white group-hover:text-black`}
                        ></i>
                      </div>
                      <h3 className="text-xl font-medium mb-1 text-white group-hover:text-black">
                        {card.title}
                      </h3>
                      <p className="text-[#86868b] text-sm group-hover:text-black">
                        {card.desc}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </>
          ) : (
            <div className="bg-[#161618] p-4 md:p-8 rounded-3xl max-w-[980px] mx-auto">
              <button
                onClick={() => setActiveCard(null)}
                className="text-red-500 hover:text-red-400 transition-colors duration-300 mb-8 flex items-center"
              >
                <i className="fas fa-chevron-left mr-2"></i>
                Zurück
              </button>

              {activeCard === "contact" && (
                <div className="space-y-4 md:space-y-6">
                  <div className="flex flex-col gap-3 md:gap-4 mb-4 md:mb-6">
                    <input
                      type="text"
                      placeholder="Filiale"
                      value={newNumber.branch}
                      onChange={(e) =>
                        setNewNumber({ ...newNumber, branch: e.target.value })
                      }
                      className="w-full px-3 md:px-4 py-2 md:py-3 rounded-xl bg-[#1d1d1f] border-none focus:ring-2 focus:ring-[#2997ff] outline-none placeholder-[#86868b]"
                    />
                    <input
                      type="text"
                      placeholder="Name"
                      value={newNumber.name}
                      onChange={(e) =>
                        setNewNumber({ ...newNumber, name: e.target.value })
                      }
                      className="w-full px-3 md:px-4 py-2 md:py-3 rounded-xl bg-[#1d1d1f] border-none focus:ring-2 focus:ring-[#2997ff] outline-none placeholder-[#86868b]"
                    />
                    <input
                      type="tel"
                      placeholder="Telefonnummer"
                      value={newNumber.number}
                      onChange={(e) =>
                        setNewNumber({ ...newNumber, number: e.target.value })
                      }
                      className="w-full px-3 md:px-4 py-2 md:py-3 rounded-xl bg-[#1d1d1f] border-none focus:ring-2 focus:ring-[#2997ff] outline-none placeholder-[#86868b]"
                    />
                    <button
                      onClick={handleAddNumber}
                      className="bg-red-500 text-white p-3 rounded-xl hover:bg-red-600 transition-colors duration-300"
                    >
                      <i className="fas fa-plus"></i>
                    </button>
                  </div>

                  <div className="space-y-3 md:space-y-4">
                    {phoneNumbers.map((phone, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between bg-[#1d1d1f] p-4 rounded-xl"
                      >
                        <div className="space-y-1">
                          <h3 className="font-medium">{phone.name}</h3>
                          <p className="text-[#86868b]">{phone.number}</p>
                          <p className="text-[#86868b]">{phone.email}</p>
                          <p className="text-[#86868b]">{phone.department}</p>
                          <p className="text-[#86868b]">{phone.branch}</p>
                        </div>
                        <button
                          onClick={() => handleDeleteNumber(index)}
                          className="text-red-500 hover:text-red-400 transition-colors duration-300"
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeCard === "eans" && (
                <div className="space-y-4 md:space-y-6">
                  <div className="flex flex-col gap-3 md:gap-4 mb-4 md:mb-6">
                    <input
                      type="text"
                      placeholder="Produktname"
                      value={newEan.name}
                      onChange={(e) =>
                        setNewEan({ ...newEan, name: e.target.value })
                      }
                      className="w-full px-3 md:px-4 py-2 md:py-3 rounded-xl bg-[#1d1d1f] border-none focus:ring-2 focus:ring-[#2997ff] outline-none placeholder-[#86868b]"
                    />
                    <input
                      type="text"
                      placeholder="EAN Code"
                      value={newEan.ean}
                      onChange={(e) =>
                        setNewEan({ ...newEan, ean: e.target.value })
                      }
                      className="w-full px-3 md:px-4 py-2 md:py-3 rounded-xl bg-[#1d1d1f] border-none focus:ring-2 focus:ring-[#2997ff] outline-none placeholder-[#86868b]"
                    />
                    <button
                      onClick={() => {
                        if (newEan.name && newEan.ean) {
                          setEans([...eans, newEan]);
                          setNewEan({ name: "", ean: "" });
                        }
                      }}
                      className="bg-red-500 text-white p-3 rounded-xl hover:bg-red-600 transition-colors duration-300"
                    >
                      <i className="fas fa-plus"></i>
                    </button>
                  </div>

                  <div className="space-y-3 md:space-y-4">
                    {eans.map((ean, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between bg-[#1d1d1f] p-4 rounded-xl"
                      >
                        <div className="space-y-1">
                          <h3 className="font-medium">{ean.name}</h3>
                          <p className="text-[#86868b]">{ean.ean}</p>
                        </div>
                        <button
                          onClick={() => {
                            const updatedEans = eans.filter(
                              (_, i) => i !== index
                            );
                            setEans(updatedEans);
                          }}
                          className="text-red-500 hover:text-red-400 transition-colors duration-300"
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeCard === "manuals" && (
                <div className="space-y-6">
                  <div className="bg-[#1d1d1f] p-6 rounded-xl">
                    <h3 className="text-xl font-medium mb-4">Dokumente</h3>
                    <div className="space-y-4">
                      {manuals.map((manual) => (
                        <div
                          key={manual.id}
                          draggable
                          onDragStart={(e) => handleDragStart(manual, e)}
                          onDragOver={handleDragOver}
                          onDrop={(e) => handleDrop(manual, e)}
                          onDragEnd={() => setDraggedManual(null)}
                          className={`flex items-center justify-between p-4 bg-[#242426] rounded-lg hover:bg-[#2c2c2e] transition-colors cursor-move relative ${
                            draggedManual?.id === manual.id ? "opacity-50" : ""
                          }`}
                        >
                          <div className="flex items-center w-full">
                            <i className="fas fa-grip-vertical text-[#86868b] mr-3 cursor-grab active:cursor-grabbing"></i>
                            <i className="fas fa-file-pdf text-red-500 text-2xl mr-4"></i>
                            <div>
                              <h4 className="font-medium">{manual.title}</h4>
                              <p className="text-sm text-[#86868b]">
                                {manual.desc}
                              </p>
                            </div>
                          </div>
                          <i className="fas fa-download text-[#86868b] ml-4"></i>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-[#1d1d1f] p-6 rounded-xl">
                    <h3 className="text-xl font-medium mb-4">
                      Video-Tutorials
                    </h3>
                    <div className="space-y-4">
                      <a
                        href="#"
                        className="flex items-center justify-between p-4 bg-[#242426] rounded-lg hover:bg-[#2c2c2e] transition-colors"
                      >
                        <div className="flex items-center">
                          <i className="fas fa-play-circle text-red-500 text-2xl mr-4"></i>
                          <div>
                            <h4 className="font-medium">Einführung</h4>
                            <p className="text-sm text-[#86868b]">
                              Erste Schritte mit der App
                            </p>
                          </div>
                        </div>
                        <i className="fas fa-external-link-alt text-[#86868b]"></i>
                      </a>

                      <a
                        href="#"
                        className="flex items-center justify-between p-4 bg-[#242426] rounded-lg hover:bg-[#2c2c2e] transition-colors"
                      >
                        <div className="flex items-center">
                          <i className="fas fa-play-circle text-red-500 text-2xl mr-4"></i>
                          <div>
                            <h4 className="font-medium">
                              Fortgeschrittene Funktionen
                            </h4>
                            <p className="text-sm text-[#86868b]">
                              Erweiterte Features und Tipps
                            </p>
                          </div>
                        </div>
                        <i className="fas fa-external-link-alt text-[#86868b]"></i>
                      </a>
                    </div>
                  </div>
                </div>
              )}

              {activeCard === "bugs" && (
                <div className="space-y-4">
                  <a
                    href="https://mediamarkt.ch.foxway.tech"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block w-full bg-red-500 text-white text-center p-4 rounded-xl hover:bg-red-600 transition-colors duration-300"
                  >
                    <i className="fas fa-recycle mr-2"></i>
                    Trade in Portal öffnen
                  </a>
                </div>
              )}

              {activeCard === "mediamarkt" && (
                <div className="space-y-4">
                  <a
                    href="https://mediamarkt.ch"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block w-full bg-red-500 text-white text-center p-4 rounded-xl hover:bg-red-600 transition-colors duration-300"
                  >
                    <i className="fas fa-external-link-alt mr-2"></i>
                    MediaMarkt Shop öffnen
                  </a>
                  <a
                    href="https://mediamarkt.ch.foxway.tech"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block w-full bg-red-500 text-white text-center p-4 rounded-xl hover:bg-red-600 transition-colors duration-300"
                  >
                    <i className="fas fa-recycle mr-2"></i>
                    Trade in Portal öffnen
                  </a>
                </div>
              )}

              {activeCard === "employees" && (
                <div className="space-y-4 md:space-y-6">
                  <div className="flex flex-col gap-3 md:gap-4 mb-4 md:mb-6">
                    <input
                      type="text"
                      placeholder="Name"
                      value={newEmployee.name}
                      onChange={(e) =>
                        setNewEmployee({ ...newEmployee, name: e.target.value })
                      }
                      className="w-full px-3 md:px-4 py-2 md:py-3 rounded-xl bg-[#1d1d1f] border-none focus:ring-2 focus:ring-[#2997ff] outline-none placeholder-[#86868b]"
                    />
                    <input
                      type="text"
                      placeholder="Personalnummer"
                      value={newEmployee.position}
                      onChange={(e) =>
                        setNewEmployee({
                          ...newEmployee,
                          position: e.target.value,
                        })
                      }
                      className="w-full px-3 md:px-4 py-2 md:py-3 rounded-xl bg-[#1d1d1f] border-none focus:ring-2 focus:ring-[#2997ff] outline-none placeholder-[#86868b]"
                    />
                    <button
                      onClick={handleAddEmployee}
                      className="bg-red-500 text-white p-3 rounded-xl hover:bg-red-600 transition-colors duration-300"
                    >
                      <i className="fas fa-plus"></i>
                    </button>
                  </div>

                  <div className="space-y-3 md:space-y-4">
                    {employees.map((employee) => (
                      <div
                        key={employee.id}
                        className="flex items-center justify-between bg-[#1d1d1f] p-4 rounded-xl"
                      >
                        <div className="space-y-1">
                          <h3 className="font-medium">{employee.name}</h3>
                          <p className="text-[#86868b]">{employee.position}</p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleDeleteEmployee(employee.id)}
                            className="text-red-500 hover:text-red-400 transition-colors duration-300"
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                          <button
                            onClick={() => {
                              const newName = prompt(
                                "Neuer Name:",
                                employee.name
                              );
                              const newPosition = prompt(
                                "Neue Personalnummer:",
                                employee.position
                              );
                              if (newName && newPosition) {
                                handleEditEmployee({
                                  ...employee,
                                  name: newName,
                                  position: newPosition,
                                });
                              }
                            }}
                            className="text-blue-500 hover:text-blue-400 transition-colors duration-300"
                          >
                            <i className="fas fa-edit"></i>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeCard === "schedule" && (
                <div className="space-y-4">
                  <div className="bg-[#1d1d1f] p-6 rounded-xl">
                    <h3 className="text-xl font-medium mb-4">
                      Media Wiesli - Media Wiesli
                    </h3>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left">
                        <thead>
                          <tr className="border-b border-[#2c2c2e]">
                            <th className="pb-3">Name</th>
                            <th className="pb-3">Mo 11</th>
                            <th className="pb-3">Di 12</th>
                            <th className="pb-3">Mi 13</th>
                            <th className="pb-3">Do 14</th>
                            <th className="pb-3">Fr 15</th>
                            <th className="pb-3">Sa 16</th>
                            <th className="pb-3">So 17</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-b border-[#2c2c2e]">
                            <td className="py-4">Media Wiesli</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">09:15-19:15</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">08:45-19:00</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">09:00-17:15</td>
                            <td className="py-4">Geschlossen</td>
                          </tr>
                          <tr className="border-b border-[#2c2c2e]">
                            <td className="py-4">Ajsela Skijil</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">09:15-19:15</td>
                            <td className="py-4">Frei</td>
                            <td className="py-4">08:45-19:00</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">Frei</td>
                            <td className="py-4">Geschlossen</td>
                          </tr>
                          <tr className="border-b border-[#2c2c2e]">
                            <td className="py-4">Anis Spahic</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">Schule</td>
                            <td className="py-4">Schule</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">Frei</td>
                            <td className="py-4">09:00-17:15</td>
                            <td className="py-4">Geschlossen</td>
                          </tr>
                          <tr className="border-b border-[#2c2c2e]">
                            <td className="py-4">Cedric Lustenberger</td>
                            <td className="py-4">Schule</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">Frei</td>
                            <td className="py-4">10:40-21:00</td>
                            <td className="py-4">09:00-17:15</td>
                            <td className="py-4">Geschlossen</td>
                          </tr>
                          <tr className="border-b border-[#2c2c2e]">
                            <td className="py-4">Fabian Egolf</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">08:30-19:00</td>
                            <td className="py-4">09:15-19:15</td>
                            <td className="py-4">Frei</td>
                            <td className="py-4">10:40-21:00</td>
                            <td className="py-4">11:00-17:15</td>
                            <td className="py-4">Geschlossen</td>
                          </tr>
                          <tr className="border-b border-[#2c2c2e]">
                            <td className="py-4">Fabian Obertüfer</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">Frei</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">07:45-17:15</td>
                            <td className="py-4">Geschlossen</td>
                          </tr>
                          <tr className="border-b border-[#2c2c2e]">
                            <td className="py-4">Fabiano Costa</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">08:45-19:00</td>
                            <td className="py-4">09:15-19:15</td>
                            <td className="py-4">Frei</td>
                            <td className="py-4">09:00-17:15</td>
                            <td className="py-4">Geschlossen</td>
                          </tr>
                          <tr className="border-b border-[#2c2c2e]">
                            <td className="py-4">Jan Behrens</td>
                            <td className="py-4">Frei</td>
                            <td className="py-4">Schule</td>
                            <td className="py-4">Schule</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">07:45-17:15</td>
                            <td className="py-4">Geschlossen</td>
                          </tr>
                          <tr className="border-b border-[#2c2c2e]">
                            <td className="py-4">Kavi Ramanan</td>
                            <td className="py-4">Frei</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">08:45-19:00</td>
                            <td className="py-4">10:40-21:15</td>
                            <td className="py-4">09:00-17:15</td>
                            <td className="py-4">Geschlossen</td>
                          </tr>
                          <tr className="border-b border-[#2c2c2e]">
                            <td className="py-4">Lars Arnet</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">Frei</td>
                            <td className="py-4">09:15-19:15</td>
                            <td className="py-4">Schule</td>
                            <td className="py-4">08:45-19:00</td>
                            <td className="py-4">07:45-17:15</td>
                            <td className="py-4">Geschlossen</td>
                          </tr>
                          <tr className="border-b border-[#2c2c2e]">
                            <td className="py-4">Luis Büttler</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">08:45-19:15</td>
                            <td className="py-4">UK</td>
                            <td className="py-4">UK</td>
                            <td className="py-4">UK</td>
                            <td className="py-4">Frei</td>
                            <td className="py-4">Geschlossen</td>
                          </tr>
                          <tr className="border-b border-[#2c2c2e]">
                            <td className="py-4">Michael Wiesli</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">Kurs</td>
                            <td className="py-4">Frei</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">08:30-21:15</td>
                            <td className="py-4">11:00-17:15</td>
                            <td className="py-4">Geschlossen</td>
                          </tr>
                          <tr className="border-b border-[#2c2c2e]">
                            <td className="py-4">Ricardo Barrero</td>
                            <td className="py-4">Frei</td>
                            <td className="py-4">09:15-19:15</td>
                            <td className="py-4">08:30-19:15</td>
                            <td className="py-4">09:15-19:15</td>
                            <td className="py-4">15:15-20:00</td>
                            <td className="py-4">09:00-17:15</td>
                            <td className="py-4">Geschlossen</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </main>
      <footer className="text-center text-[#86868b] text-sm py-4">
        © 2024 by Fabiano
      </footer>
    </div>
  );
}

<style jsx global>{`
  @keyframes slide-in {
    from {
      transform: translateX(-100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }

  .animate-slide-in {
    animation: slide-in 0.5s ease-out forwards;
  }
`}</style>;

export default MainComponent;